package TugasUAS.Soal2;

public abstract class Hero {
    public String nama_hero;
    public String role;

    public int vitality;
    public int strength;
    public int intelligence;

    public abstract void healing();
}
